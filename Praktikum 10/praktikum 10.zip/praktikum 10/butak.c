/**
 * NIM : 13521074
 * Nama : Eugene Yap Jin Quan
 * Tanggal : 2022-11-10
 * Topik praktikum : Queue dan Stack dengan struktur berkait
 * Deskripsi : butak.c
 */
 
#include <stdio.h>
#include "queuelinked.h"
#include "charmachine.h"

boolean isElHomogen(Queue q) {
	Address p = ADDR_HEAD(q);
	boolean isHomo = true;

	while (p != NIL && isHomo) {
		if (INFO(p) != HEAD(q)) {
			isHomo = false;
		} else {
			p =	NEXT(p);
		}
	}
	return isHomo;
}

void outSand(int index){
	if (index == 0) {
		printf("bulat\n");
	} else if (index == 1) {
		printf("kotak\n");
	}
}

int main() {
	Queue mhs, pref, sand;
	CreateQueue(&mhs);
	CreateQueue(&pref);
	CreateQueue(&sand);
	
		
	int i;
	for (i = 1; i <= 4; i++) {
		enqueue(&mhs, i);
	}
	

	START();
	while (currentChar != ',') {
		if (currentChar == 'B') {
			enqueue(&pref, 0);
		} else if (currentChar == 'K') {
			enqueue(&pref, 1);
		}
		ADV();
	}
	ADV();
	while (!EOP) {
		if (currentChar == 'B') {
			enqueue(&sand, 0);
		} else if (currentChar == 'K') {
			enqueue(&sand, 1);
		}
		ADV();
	}
	
	int noMhs, noSand, noPref;
	int len = length(mhs);
	while (true) {
		if (HEAD(pref) == HEAD(sand)) {
			dequeue(&mhs, &noMhs);
			dequeue(&sand, &noSand);
			dequeue(&pref, &noPref);
			
			printf("%d -> ", noMhs);
			outSand(noPref);
			len--;
		} else {
			dequeue(&mhs, &noMhs);
			dequeue(&pref, &noPref);
			

		}
		
		if(isEmpty(sand)) {
			break;
		} else if (isElHomogen(pref) && isElHomogen(sand) && noPref != HEAD(sand)) {
			break;
		}
		else {
			enqueue(&mhs, noMhs);
			enqueue(&pref, noPref);
		}
	}
	printf("%d\n", len);

	return 0;
}
