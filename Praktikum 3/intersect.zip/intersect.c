/*
NIM : 13521074
Nama : Eugene Yap Jin Quan
Tanggal : 15/09/2022
Topik praktikum : ADT List Statik dan Dinamik
Deskripsi : intersect.c
*/

#include <stdio.h>
#include "liststatik.h"

int main(){
	ListStatik N,M, NnM;
	readList(&N);
	readList(&M);
	
	sortList(&N, true);
	sortList(&M, true);
	
	// mencari intersect
	int i, j;
	int idx = 0;
	int lenN = listLength(N);
	int lenM = listLength(M);
	CreateListStatik(&NnM);
	for (i=0;i<lenN;i++){
		for (j=0;j<lenM;j++){
			if (ELMT(N,i)==ELMT(M,j)){
				ELMT(NnM, idx) = ELMT(N,i);
				idx++;
			}
		}
	}
	
	printf("%d\n", listLength(NnM));
	printList(NnM);
	putchar('\n');
	
	return 0;
}
