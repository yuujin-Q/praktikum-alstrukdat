/*
NIM : 13521074
Nama : Eugene Yap Jin Quan
Tanggal : 15/09/2022
Topik praktikum : ADT List Statik dan Dinamik
Deskripsi : merge.c
*/


#include <stdio.h>
#include "listdin.h"

int main(){
	ListDin N, M, NuM;
	CreateListDin(&N, 200);
	CreateListDin(&M, 200);
	CreateListDin(&NuM, 400);
	
	readList(&N);
	readList(&M);
	
	int i; // union
	for (i=0;i<listLength(N);i++){
		insertLast(&NuM, ELMT(N,i));
	}
	for (i=0;i<listLength(M);i++){
		if(countVal(NuM, ELMT(M,i))==0){
			insertLast(&NuM, ELMT(M,i));
		}
	}
	//print
	sort(&NuM, true);
	printf("%d\n", listLength(NuM));
	printList(NuM);
	putchar('\n');
	
	return 0;
}
