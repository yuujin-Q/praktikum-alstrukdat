/*
NIM : 13521074
Nama : Eugene Yap Jin Quan
Tanggal : 15/09/2022
Topik praktikum : ADT List Statik dan Dinamik
Deskripsi : olist.c
*/

#include <stdio.h>
#include "liststatik.h"

void reverselist(ListStatik *l){
	int i, temp;
	int len = listLength(*l);
	for (i = IDX_MIN; i < len/2; i++)
         {
            temp = ELMT(*l,i);
            ELMT(*l,i) = ELMT(*l,(len-1)-i);
            ELMT(*l,(len-1)-i) = temp;
         }  
}

int countVal(ListStatik l, ElType val){
    int i, count=0;
    int len = listLength(l);
    for (i = IDX_MIN; i < len; i++)
    {
        if (ELMT(l,i)==val){
            count++;
        }
    }
    return count;
};

int main(){
	ListStatik data, datareverse;
	readList(&data);
		
	int x;
	scanf("%d", &x);
		
	datareverse = data;
	reverselist(&datareverse);
	
	printList(data); //cetak list
	putchar('\n');
	

	int countX;	//cetak banyak dan kemunculan terakhir 
	countX = countVal(datareverse, x);
	printf("%d\n", countX);
	if (countX == 0){
		printf("%d tidak ada\n", x);
	}
	else{
		int lastfound;
		lastfound = getLastIdx(datareverse) - indexOf(datareverse, x);	
		printf("%d\n", lastfound);
	}
	
	// mencari extrema dan median
	sortList(&data, true);
	int maxi, mini, medi;
	extremeValues(data, &maxi, &mini);
	medi = ELMT(data, getLastIdx(data)/2);
	
	if(x==maxi){
		printf("maksimum\n");
	}	
	if(x==mini){
		printf("minimum\n");
	}
	if(x==medi){
		printf("median\n");
	}

	return 0;
}
