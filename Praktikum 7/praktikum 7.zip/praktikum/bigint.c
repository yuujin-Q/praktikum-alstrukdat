/*
NIM: 13521074
Nama: Eugene Yap Jin Quan 
Tanggal: 20/10/2022
Topik praktikum: ADT Stack
Deskripsi: bigint.c
*/

#include <stdio.h>
#include <math.h>
#include "stack.h"

int toDigit(char c){
	return (int)c - 48;
}

int tenthPow(int i){
	if(i==0){
		return 1;
	}
	else{
		return 10*tenthPow(i-1);
	}
}

int main(){
	Stack S1, S2, result;
	CreateEmpty(&S1);
	CreateEmpty(&S2);
	CreateEmpty(&result);
	
	char c1, c2;
	int count1=0, count2=0;
	
	scanf("%c", &c1);
	while(c1 != '\n' && !IsFull(S1)){
		count1++;
		Push(&S1, toDigit(c1));
		scanf("%c", &c1);
	};
	
	scanf("%c", &c2);
	while(c2 != '\n' && !IsFull(S2)){
		count2++;
		Push(&S2, toDigit(c2));
		scanf("%c", &c2);
	};
	
	
	int x1, x2, countres=0;
	if(count1<=count2){
		while(!IsEmpty(S1)){
			Pop(&S1,&x1);
			Pop(&S2,&x2);
			Push(&result, x1-x2);
			countres++;
		}
		while(!IsEmpty(S2)){
			Pop(&S2,&x2);
			Push(&result, 0-x2);
			countres++;
		}
	}
	else{
		while(!IsEmpty(S2)){
			Pop(&S1,&x1);
			Pop(&S2,&x2);
			Push(&result, x1-x2);
			countres++;
		}
		while(!IsEmpty(S1)){
			Pop(&S1,&x1);
			Push(&result, x1);
			countres++;
		}
	}
	
	
	int res=0,i,x;
	for(i=countres-1;i>=0;i--){
		Pop(&result,&x);
		res+=(int)pow(10,i)*x;
	}
	
	printf("%d\n", res);
	
	
	return 0;
}
